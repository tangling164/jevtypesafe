import { mkdirSync, writeFileSync } from 'node:fs';
mkdirSync('data/records', { recursive: true });
mkdirSync('data/taxonomy', { recursive: true });
const examples = [
  ['lantern', 'routing', 'jev', 'open_source', 'MIT', true, 'A fictional message router.', '虚构的消息路由测试项目。'],
  ['pebble', 'data', 'jev_integration', 'source_available', null, false, 'A fictional data labeling tool.', '虚构的数据标注测试工具。'],
  ['orbit', 'routing', 'jev_like', 'demo_only', null, null, 'A fictional routing demonstration.', '虚构的路由演示测试项目。'],
];
for (const [slug, category, ecosystem, source_status, spdx, local_install, en, zh] of examples) {
  const record = {
    kind: 'project', slug, name: `Fixture ${slug}`, category,
    description: en, summary: en, licenses: spdx ? [spdx] : [],
    links: {website: `https://example.com/fixtures/${slug}`},
    source: { type: 'manual' }, curation: { reviewed: false },
    id: `synthetic-stable-${slug}-001`, fictional: true,
    locales: {en: {summary: en}, zh: {summary: zh}}, ecosystem, source_status,
    license: spdx ? {spdx, url: `https://example.com/fixtures/${slug}/license`} : null,
    requirements: {api_key: null, additional_model: null, local_install, hardware: null},
    sources: [{type: 'website', url: `https://example.com/fixtures/${slug}`, checked_at: '2026-09-22'}],
    verification: 'fixture_only',
  };
  // JSON is valid YAML; these files still exercise Grove's actual YAML parser.
  writeFileSync(`data/records/${slug}.yml`, JSON.stringify(record, null, 2) + '\n');
}
writeFileSync('data/taxonomy/categories.yml', JSON.stringify([{id: 'routing', name: 'Fixture routing'}, {id: 'data', name: 'Fixture data'}], null, 2));
writeFileSync('data/taxonomy/licenses.yml', JSON.stringify([{id: 'MIT', name: 'MIT'}]));
