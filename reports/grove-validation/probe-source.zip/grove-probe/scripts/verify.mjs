import { chromium, expect } from '@playwright/test';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, existsSync, readdirSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
const mode = process.argv[2] || 'adapted';
const base = mode === 'native' ? 'http://127.0.0.1:8792' : 'http://127.0.0.1:8791';
const evidence = new URL('../../evidence/', import.meta.url);
mkdirSync(evidence, {recursive:true});
const results = [];
async function check(name, fn) {
  try { const details = await fn(); results.push({name,passed:true,details}); }
  catch (error) { results.push({name,passed:false,error:String(error.stack)}); }
  console.log(`${results.at(-1).passed ? 'PASS' : 'FAIL'} ${name}`);
}
const browser = await chromium.launch({headless:true});
try {
  if (mode === 'native') {
    await check('Native generated JSON strips required fields', async () => {
      const fields = ['id','locales','ecosystem','source_status','license','requirements','sources','verification'];
      for (const file of ['records.full.json','records.index.json']) {
        const { records } = JSON.parse(readFileSync(`data/generated/${file}`, 'utf8'));
        assert.equal(records.length,3);
        for (const row of records) for (const field of fields) assert.equal(field in row,false);
      }
      return {expectedLimitation:true,fields};
    });
    await check('Native scaffold has no Chinese route', async () => {
      assert.equal(existsSync('dist/zh/index.html'), false);
      assert.equal((await fetch(base + '/zh/')).status,404);
      return {expectedLimitation:true};
    });
    await check('Native list, category and detail without JavaScript', async () => {
      const context = await browser.newContext({javaScriptEnabled:false});
      const page = await context.newPage();
      for (const path of ['/','/projects/','/categories/routing/','/projects/lantern/']) {
        assert.equal((await page.goto(base+path)).status(),200);
        await expect(page.locator('body')).toContainText('Fixture lantern');
      }
      await context.close();
    });
    await check('Native client search and license filter', async () => {
      const page = await browser.newPage();
      await page.goto(base+'/projects/');
      await expect(page.locator('#results-list > [data-record-slug]')).toHaveCount(3);
      await page.locator('#search-input').fill('lantern');
      await expect(page.locator('#results-list > [data-record-slug]')).toHaveCount(1);
      await expect(page.locator('#results-list')).toContainText('Fixture lantern');
      await page.goto(base+'/projects/?license=MIT');
      await expect(page.locator('#results-list > [data-record-slug]')).toHaveCount(1);
      await expect(page.locator('#results-list')).toContainText('Fixture lantern');
      await page.close();
    });
  } else {
    const fixtures = readdirSync('data/records').filter(f => f.endsWith('.yml')).map(f=>JSON.parse(readFileSync(join('data/records',f),'utf8')));
    const paths = ['', 'projects', 'search', 'categories/routing','categories/data', ...fixtures.map(r=>'projects/'+r.slug)];
    await check('16 static bilingual routes bypass Worker; no server bundle', async () => {
      for (const locale of ['en','zh']) for (const path of paths) {
        const route = `${locale === 'zh' ? '/zh' : ''}/${path}${path ? '/' : ''}`;
        const filename = join('dist-adapted',route,'index.html');
        const response = await fetch(base+route);
        assert.equal(response.status,200,route);
        assert.equal(response.headers.get('x-probe-worker'),null,route);
        assert.equal(await response.text(),readFileSync(filename,'utf8'),route);
      }
      assert.equal(existsSync('dist-adapted/server'),false);
      assert.equal(existsSync('dist-adapted/_worker.js'),false);
      return {routes:16};
    });
    await check('Stable IDs, both summaries and all required custom fields in static detail HTML', async () => {
      for (const fixture of fixtures) for (const locale of ['en','zh']) {
        const html = readFileSync(join('dist-adapted',locale==='zh'?'zh':'','projects',fixture.slug,'index.html'),'utf8');
        assert.ok(html.includes(fixture.id)); assert.ok(html.includes(fixture.locales[locale].summary));
        for (const key of ['ecosystem','source_status','license','requirements','sources','verification']) assert.ok(html.includes(key),key);
      }
      return {fixtures:3,details:6};
    });
    await check('Asset distribution, license preservation, true 404 and isolated API', async () => {
      // This small Astro page inlines its JS/CSS; check an actual emitted static asset.
      for (const route of ['/icons/platforms/android.svg','/licenses/Grove-MIT.txt','/licenses/Open-Apps-MIT.txt']) {
        const response = await fetch(base+route); assert.equal(response.status,200);
        assert.equal(response.headers.get('x-probe-worker'),null);
      }
      const api = await fetch(base+'/api/sponsors/health');
      assert.equal(api.headers.get('x-probe-worker'),'sponsors');
      assert.equal(api.headers.get('cache-control'),'no-store');
      assert.deepEqual(await api.json(),{fixture:true,scope:'sponsors',implemented:false});
      for (const route of ['/missing-fixture/','/api/sponsors/missing']) {
        const response = await fetch(base+route); assert.equal(response.status,404);
        assert.ok((await response.text()).includes('Fixture not found'));
      }
    });
    await check('No-JS navigation, category and same-project language switch', async () => {
      const context = await browser.newContext({javaScriptEnabled:false});
      const page = await context.newPage();
      await page.goto(base+'/zh/'); await expect(page.locator('article')).toHaveCount(3);
      await page.locator('nav[aria-label="Categories"] a[href$="/routing/"]').click();
      await expect(page.locator('article')).toHaveCount(2);
      await page.locator('h2 a').filter({hasText:'lantern'}).click();
      await expect(page.locator('[data-summary]')).toHaveText('虚构的消息路由测试项目。');
      await page.locator('[data-language]').click();
      assert.equal(new URL(page.url()).pathname,'/projects/lantern/');
      await expect(page.locator('[data-stable-id]')).toHaveText('synthetic-stable-lantern-001');
      await expect(page.locator('[data-summary]')).toHaveText('A fictional message router.');
      await context.close();
    });
    await check('Chinese search, ecosystem/source filters, unknown handling, empty/reset and URL reload', async () => {
      const page = await browser.newPage();
      const visible = page.locator('article:not([hidden])');
      await page.goto(base+'/zh/search/');
      await page.locator('[name=q]').fill('消息'); await expect(visible).toHaveCount(1);
      await page.locator('button[type=reset]').click(); await expect(visible).toHaveCount(3);
      await page.locator('[name=ecosystem]').selectOption('jev'); await expect(visible).toHaveCount(1);
      await page.locator('[name=source_status]').selectOption('demo_only'); await expect(visible).toHaveCount(0);
      await expect(page.locator('#empty')).toBeVisible();
      await page.locator('button[type=reset]').click(); await expect(visible).toHaveCount(3);
      await page.locator('[name=local]').selectOption('true'); await expect(visible).toHaveCount(1);
      await page.locator('[name=local]').selectOption('unknown');
      await expect(visible).toHaveCount(1); await expect(visible).toContainText('Fixture orbit');
      await page.reload(); await expect(visible).toHaveCount(1); await expect(visible).toContainText('Fixture orbit');
      await page.locator('[data-language]').click(); await expect(visible).toHaveCount(1);
      await page.close();
    });
    await check('375px/1440px layout and canonical/hreflang, sitemap, preview noindex', async () => {
      const page = await browser.newPage();
      for (const width of [375,1440]) {
        await page.setViewportSize({width,height:900}); await page.goto(base+'/zh/');
        assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
        await page.screenshot({path:new URL(`adapted-${width}.png`,evidence).pathname.replace(/^\/(\w:)/,'$1'),fullPage:true});
      }
      await page.goto(base+'/zh/projects/lantern/');
      await expect(page.locator('link[rel=canonical]')).toHaveAttribute('href','https://jevtypesafe.dev/zh/projects/lantern/');
      await expect(page.locator('link[hreflang=en]')).toHaveAttribute('href','https://jevtypesafe.dev/projects/lantern/');
      await expect(page.locator('meta[name=robots]')).toHaveAttribute('content','noindex,nofollow');
      const sitemap = await (await fetch(base+'/sitemap.xml')).text();
      assert.equal((sitemap.match(/<loc>/g)||[]).length,14);
      assert.ok(sitemap.includes('/zh/projects/lantern/'));
      assert.ok((await (await fetch(base+'/robots.txt')).text()).includes('Disallow: /'));
      await page.close();
    });
  }
} finally {
  await browser.close();
  writeFileSync(new URL(`${mode}-verification.json`,evidence),JSON.stringify({date:new Date().toISOString(),mode,base,results},null,2)+'\n');
}
process.exitCode = results.some(r=>!r.passed)?1:0;
