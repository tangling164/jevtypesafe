import { spawnSync } from 'node:child_process';
const result = spawnSync(process.execPath, ['node_modules/astro/bin/astro.mjs', process.argv[2] || 'build'], {
  stdio: 'inherit', env: { ...process.env, PROBE_MODE: 'adapted' },
});
process.exit(result.status ?? 1);
