import { readFileSync, writeFileSync } from 'node:fs';
import { projectRecordSchema, defineConfig } from '@grove-dev/core';
// White-box inspection of the generator projection, not a production extension API.
import { toIndexRecord } from '../node_modules/@grove-dev/core/dist/schema.js';
const input = JSON.parse(readFileSync('data/records/lantern.yml', 'utf8'));
const record = projectRecordSchema.parse(input);
const index = toIndexRecord(record);
const fields = ['id', 'locales', 'ecosystem', 'source_status', 'license', 'requirements', 'sources', 'verification'];
let customFacet;
try { defineConfig({
  blueprint: 'project-directory', site: { name: 'Fixture lab', url: 'https://jevtypesafe.dev' },
  browse: { facets: ['category', 'ecosystem', 'source_status'] },
}); customFacet = {success: true}; } catch (error) { customFacet = {success: false, error}; }
const report = {
  date: new Date().toISOString(), packageVersion: '0.11.0',
  nativeRecordParses: true,
  fields: fields.map(name => ({ name, presentInInput: name in input, preservedInRecord: name in record, preservedInIndex: name in index })),
  customFacetAccepted: customFacet.success,
  customFacetErrors: customFacet.success ? [] : customFacet.error.issues.map(i => ({path: i.path, message: i.message})),
  nativeIdentity: { slug: record.slug, separateStableId: 'id' in record },
};
writeFileSync('../evidence/native-schema.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));

