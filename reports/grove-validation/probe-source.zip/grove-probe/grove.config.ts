import { defineConfig } from '@grove-dev/core';
export default defineConfig({
  blueprint: 'project-directory',
  site: {
    name: 'Jev compatibility lab',
    tagline: 'Fictional fixtures for local compatibility testing only',
    description: 'Not a production directory. Every record is invented test data.',
    url: 'https://jevtypesafe.dev',
    locale: 'en',
  },
  nav: [{label: 'Fixtures', href: '/projects/'}],
  browse: { facets: ['category', 'license'] },
  integrations: { github: false },
});
