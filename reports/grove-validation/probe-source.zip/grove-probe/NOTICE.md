# Third-party provenance

- Grove packages and generated scaffold: version 0.11.0, MIT, Copyright (c) 2026 Turtuvshin Byambaa. Research checkout: `ef69963b95a0bc80c3b904de4b0d7ca9579a9d34`, https://github.com/tortuvshin/grove. Full notice: `licenses/Grove-MIT.txt`.
- Open App Scout reference source: https://github.com/tortuvshin/open-apps at `17c1187fb81131f9d0d6ffc1cfc2dadbf9dbb8cb`, MIT, Copyright (c) 2024–2026 Open Apps contributors. Full notice, including its legacy CC0 seed-list note: `licenses/Open-Apps-MIT.txt`. Its source was inspected read-only; its content, branding, logo, example records, images and editorial copy were not imported.
- This probe's records and summaries were invented solely for compatibility tests. They must not become production content. Grove supplies some generic stack/platform icons during integration setup; these are framework assets, not images copied from the reference website.
- Package dependencies retain their own notices in their distributed packages. The lockfile identifies exact resolved artifacts.
