// @ts-check
import { defineConfig } from "astro/config";
import tailwindcss from "@tailwindcss/vite";
import groveAstro from "@grove-dev/astro";
import { loadConfig } from "@grove-dev/core";

// `site` is the canonical URL the build uses for absolute links
// (sitemap, OpenGraph, canonical tags, JSON-LD). Read from
// grove.config.ts and overridable per build via SITE_URL.
const groveConfig = await loadConfig();

export default defineConfig({
  srcDir: process.env.PROBE_MODE === 'adapted' ? './probe-src' : './src',
  publicDir: process.env.PROBE_MODE === 'adapted' ? './probe-public' : './public',
  outDir: process.env.PROBE_MODE === 'adapted' ? './dist-adapted' : './dist',
  output: 'static',
  site: process.env.SITE_URL || groveConfig.site.url,
  trailingSlash: "ignore",
  integrations: [groveAstro()],
  vite: {
    plugins: [tailwindcss()],
  },
  build: {
    format: "directory",
  },
});
