# Grove 0.11 compatibility probe

This is an isolated technical experiment for jevtypesafe.dev, not the production site or an approved migration. All three records are fictional. No Open App Scout project data, brand assets, images or editorial text are used.

## Two independently inspectable modes

- `src/`: Grove CLI's bundled 72-file scaffold, with lab configuration and invented records. Native build goes to `dist/`.
- `probe-src/`: application-owned bilingual routes, Zod sidecar adapter, search/filter controller and sitemap. Adapted build goes to `dist-adapted/`. It still invokes the real Grove integration but reads custom fields separately because Grove strips them.
- `data/records/`: one JSON-compatible YAML file per fixture, shared ID and en/zh summaries.
- `worker.js`: **test stub only**. `/api/sponsors/health` returns `implemented: false`; no sponsorship, D1 or statistics functionality exists.

## Reproduce (Windows PowerShell)

Use Node 24.14.1 and npm 11.11.0. Dependencies and lockfile are pinned. Extract the source archive into an empty directory; do not overlay the production repository. Commands below are reproduction instructions; the report and evidence logs distinguish what was actually run.

```powershell
npm ci
New-Item -ItemType Directory -Path ../evidence -Force
npm run build
npm run check
node scripts/native-schema.mjs
```

In one terminal start the native static preview:

```powershell
$env:WRANGLER_SEND_METRICS='false'
npx wrangler dev --config wrangler.native.jsonc --port 8792 --persist-to .wrangler/native
```

In another terminal run `node scripts/verify.mjs native`, then stop that preview before starting the adapted one. Native checks intentionally confirm the **absence** of custom fields and `/zh/`; their passing assertions do not mean those capabilities are supported.

```powershell
$env:RAYON_NUM_THREADS='2'
npm run build:adapted
npm run check:adapted
npm run preview:cloudflare
```

In another terminal run `node scripts/verify.mjs adapted`. Inspect `/`, `/zh/`, `/projects/lantern/`, `/zh/search/`, and `/api/sponsors/health` on `http://127.0.0.1:8791`. Tests write evidence to the sibling `evidence/` directory. Chromium must be available to Playwright; if missing, install it with `npx playwright install chromium`. Browser and package installation require network; seeded builds do not require AI/GitHub credentials.

Cloudflare packaging inspection: `npx wrangler deploy --dry-run --outdir ../evidence/worker-bundle`. This is not a deployment. In this environment the bundle was emitted and the CLI printed its completion message, but did not terminate and was interrupted. Local workerd routing was separately tested successfully. No account, DNS, HTTPS or production deployment was verified.

## Bootstrap limitation

The stock command `npx @grove-dev/cli@0.11.0 init grove-probe --no-install --no-git` failed on Windows because its package-manager subprocess did not recognize installed npm. This probe used the published CLI's internal `initDirectory` with an injected installer that triggers its bundled registry fallback, then ran npm install explicitly. No upstream package files were patched. This internal workaround is not a supported production initialization API. The archived scaffold can be inspected and installed directly without repeating it.

## Scope and limitations

The adapter is a proof of feasibility, not a migration library. It supports three fixtures with complete translations and a small single-select filter form; it does not implement production pagination, missing translations, same-dimension multi-select OR, repository rename redirects, override/tombstone migration, capacity targets or sponsor business logic. Native TypeScript configuration remains the upstream scaffold's `strict: false`; successful `astro check` is not evidence of production strict-mode compliance.

Stable IDs live in the sidecar input, not Grove's generated records. All custom fields must be kept out of a destructive normalization round-trip through the native schema. The adapter gates publication through Grove's visible index and validates a public-field allowlist. Production migration would need additional boundary tests and one authoritative JSON-to-Grove projection, not two manually maintained datasets.

All adapted pages are noindex and robots disallows crawling. Grove's native scaffold outputs are preserved separately for comparison. This minimal layout is not a UI proposal or a completion of the earlier Taste work.

## Attribution

Grove MIT and Open Apps MIT notices are preserved verbatim in `licenses/`, and distributed in the probe's public license paths. See `NOTICE.md`. Open App Scout is only the reference site's name; it is not this probe's branding.
