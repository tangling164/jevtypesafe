import { loadFixtures, routes } from '../lib/records';
export function GET() {
  return new Response('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
    + routes(loadFixtures()).filter(r => r.path !== 'search').map(r => `<url><loc>https://jevtypesafe.dev${r.url}</loc></url>`).join('')
    + '</urlset>', { headers: { 'Content-Type': 'application/xml' } });
}
