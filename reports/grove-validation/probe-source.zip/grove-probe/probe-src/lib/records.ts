import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { parse } from 'yaml';
import { z } from 'zod';

// Application-owned sidecar adapter: Grove 0.11 strips these custom fields.
// Read the visible index first; never expose hidden records from records.full.
const summary = z.object({ summary: z.string().min(1) });
const customRecord = z.object({
  slug: z.string().regex(/^[a-z0-9-]+$/), id: z.string().min(1),
  fictional: z.literal(true), name: z.string(), category: z.string(),
  locales: z.object({ en: summary, zh: summary }),
  ecosystem: z.enum(['jev', 'jev_integration', 'jev_like']),
  source_status: z.enum(['open_source', 'source_available', 'demo_only']),
  license: z.object({ spdx: z.string(), url: z.url() }).nullable(),
  requirements: z.object({
    api_key: z.boolean().nullable(), additional_model: z.boolean().nullable(),
    local_install: z.boolean().nullable(), hardware: z.string().nullable(),
  }),
  sources: z.array(z.object({ type: z.string(), url: z.url(), checked_at: z.iso.date() })).min(1),
  verification: z.literal('fixture_only'),
});
export type Fixture = z.infer<typeof customRecord>;
export type Locale = 'en' | 'zh';
export function loadFixtures(): Fixture[] {
  const root = process.cwd();
  const index = z.object({ records: z.array(z.object({ slug: z.string() })) })
    .parse(JSON.parse(readFileSync(join(root, 'data/generated/records.index.json'), 'utf8')));
  const visible = new Set(index.records.map(r => r.slug));
  const records = readdirSync(join(root, 'data/records')).filter(p => p.endsWith('.yml'))
    .map(file => customRecord.parse(parse(readFileSync(join(root, 'data/records', file), 'utf8'))));
  if (new Set(records.map(r => r.id)).size !== records.length) throw new Error('Duplicate stable ID');
  if (new Set(records.map(r => r.slug)).size !== records.length) throw new Error('Duplicate slug');
  return records.filter(r => visible.has(r.slug));
}
export function routes(records: Fixture[]) {
  const paths = ['', 'projects', 'search',
    ...[...new Set(records.map(r => r.category))].map(c => `categories/${c}`),
    ...records.map(r => `projects/${r.slug}`)];
  return (['en', 'zh'] as const).flatMap(locale => paths.map(path => ({
    locale, path, url: `${locale === 'zh' ? '/zh' : ''}/${path}${path ? '/' : ''}`,
  })));
}
